#pragma once

#include <vector>

using State = std::vector<std::vector<int>>;